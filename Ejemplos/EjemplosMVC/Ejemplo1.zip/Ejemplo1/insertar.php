<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Pagina principal</title>
  </head>
  <body>
    <h2>AÑADIR NUEVO ALUMNO</h2>
    <form action="nuevoAlumno.php" method="POST">
      Nombre:<input type="text" name="nombre"><br>
      Apellidos:<input type="text" name="apellidos"><br>
      Edad:<input type="text" name="edad"><br>
      <input type="submit" value="Enviar">
    </form>
  </body>
</html>
